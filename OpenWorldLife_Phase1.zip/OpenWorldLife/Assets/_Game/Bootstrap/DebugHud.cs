using Game.Core;
using Game.Optimization;
using UnityEngine;

namespace Game.Bootstrap
{
    /// <summary>Add to any GameObject to verify Phase 1 on a device: FPS, tier, in-game time, tier buttons.</summary>
    public class DebugHud : MonoBehaviour
    {
        float _fps;
        void Update() => _fps = Mathf.Lerp(_fps, 1f / Mathf.Max(Time.unscaledDeltaTime, 0.0001f), 0.1f);

        void OnGUI()
        {
            var s = new GUIStyle(GUI.skin.label) { fontSize = Mathf.RoundToInt(Screen.height * 0.03f) };
            ServiceLocator.TryGet<IQualityService>(out var q);
            ServiceLocator.TryGet<IGameClock>(out var c);
            string tier = q != null ? q.Current.tier.ToString() : "?";
            string time = c != null ? $"Day {c.Day} {c.TimeOfDayHours:00.0}h" : "?";
            GUI.Label(new Rect(20, 20, Screen.width, Screen.height * 0.1f), $"{_fps:0} FPS | {tier} | {time}", s);

            float bh = Screen.height * 0.08f, bw = Screen.width * 0.12f;
            string[] names = { "LOW", "MED", "HIGH", "ULTRA" };
            for (int i = 0; i < 4; i++)
                if (GUI.Button(new Rect(20 + i * (bw + 10), Screen.height * 0.12f, bw, bh), names[i]) && q != null)
                    q.SetTier((QualityTier)i);
        }
    }
}
