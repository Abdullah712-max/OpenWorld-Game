using Game.Core;
using Game.Optimization;
using UnityEngine;

namespace Game.Bootstrap
{
    /// <summary>Runs before the first scene loads, so every scene gets the core services. No scene setup required.</summary>
    public static class GameBootstrap
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void Init()
        {
            var root = new GameObject("[Game]");
            Object.DontDestroyOnLoad(root);

            root.AddComponent<GameClock>();

            var quality = new QualityManager();
            ServiceLocator.Register<IQualityService>(quality);
            quality.Initialize();

            Debug.Log("[Bootstrap] Core services ready: GameClock, QualityManager");
        }
    }
}
