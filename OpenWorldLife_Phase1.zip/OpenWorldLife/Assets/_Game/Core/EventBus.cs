using System;

namespace Game.Core
{
    /// <summary>Typed pub/sub so systems never reference each other directly.
    /// Events are structs, e.g. struct HourChanged { public int Hour; }.</summary>
    public static class EventBus
    {
        static class Channel<T> where T : struct
        {
            public static event Action<T> Raised;
            public static void Raise(T e) => Raised?.Invoke(e);
            public static void Clear() => Raised = null;
        }

        public static void Subscribe<T>(Action<T> handler) where T : struct => Channel<T>.Raised += handler;
        public static void Unsubscribe<T>(Action<T> handler) where T : struct => Channel<T>.Raised -= handler;
        public static void Publish<T>(T evt) where T : struct => Channel<T>.Raise(evt);
        /// <summary>Call from tests / when domain reload is disabled.</summary>
        public static void ClearAll<T>() where T : struct => Channel<T>.Clear();
    }
}
