using UnityEngine;

namespace Game.Core
{
    public struct MinuteTick { public int Day; public int Hour; public int Minute; }
    public struct HourChanged { public int Day; public int Hour; }
    public struct DayChanged { public int Day; }

    public interface IGameClock
    {
        int Day { get; }
        float TimeOfDayHours { get; }   // 0..24
        bool IsNight { get; }
        float TimeScale { get; set; }   // in-game minutes per real second
    }

    /// <summary>24h world clock. Drives lighting, traffic, NPC schedules, businesses (via events).</summary>
    public class GameClock : MonoBehaviour, IGameClock
    {
        [SerializeField] float startHour = 8f;
        [Tooltip("In-game minutes per real second. 1 = a full day in 24 real minutes.")]
        [SerializeField] float inGameMinutesPerSecond = 1f;

        float _minutes;      // total in-game minutes since start of day 0
        int _lastMinute = -1, _lastHour = -1, _lastDay = -1;

        public int Day => Mathf.FloorToInt(_minutes / 1440f);
        public float TimeOfDayHours => (_minutes % 1440f) / 60f;
        public bool IsNight => TimeOfDayHours < 6f || TimeOfDayHours >= 20f;
        public float TimeScale { get => inGameMinutesPerSecond; set => inGameMinutesPerSecond = Mathf.Max(0f, value); }

        void Awake() { _minutes = startHour * 60f; ServiceLocator.Register<IGameClock>(this); }
        void OnDestroy() => ServiceLocator.Unregister<IGameClock>();

        void Update()
        {
            _minutes += Time.deltaTime * inGameMinutesPerSecond;
            int total = Mathf.FloorToInt(_minutes);
            if (total == _lastMinute) return;
            _lastMinute = total;

            int day = total / 1440, hour = (total % 1440) / 60, minute = total % 60;
            if (day != _lastDay) { _lastDay = day; EventBus.Publish(new DayChanged { Day = day }); }
            if (hour != _lastHour) { _lastHour = hour; EventBus.Publish(new HourChanged { Day = day, Hour = hour }); }
            EventBus.Publish(new MinuteTick { Day = day, Hour = hour, Minute = minute });
        }

        // Save system hooks
        public float GetTotalMinutes() => _minutes;
        public void SetTotalMinutes(float m) { _minutes = Mathf.Max(0f, m); }
    }
}
