using System;
using System.Collections.Generic;

namespace Game.Core
{
    /// <summary>Minimal service registry. Register interfaces, resolve by interface.</summary>
    public static class ServiceLocator
    {
        static readonly Dictionary<Type, object> Services = new Dictionary<Type, object>();

        public static void Register<T>(T service) where T : class
        {
            if (service == null) throw new ArgumentNullException(nameof(service));
            Services[typeof(T)] = service;
        }

        public static bool TryGet<T>(out T service) where T : class
        {
            if (Services.TryGetValue(typeof(T), out var o)) { service = (T)o; return true; }
            service = null; return false;
        }

        public static T Get<T>() where T : class
        {
            if (TryGet<T>(out var s)) return s;
            throw new InvalidOperationException($"Service not registered: {typeof(T).Name}");
        }

        public static void Unregister<T>() where T : class => Services.Remove(typeof(T));
        public static void Clear() => Services.Clear();
    }
}
