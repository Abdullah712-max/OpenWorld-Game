using UnityEngine;

namespace Game.Optimization
{
    /// <summary>Heuristic device tiering. Thresholds are starting points: tune with real device tests.</summary>
    public static class DeviceProfiler
    {
        public static QualityTier Recommend()
        {
            int ramMb = SystemInfo.systemMemorySize;
            int cores = SystemInfo.processorCount;
            bool gles3 = SystemInfo.graphicsShaderLevel >= 45;
            bool vulkan = SystemInfo.graphicsDeviceType == UnityEngine.Rendering.GraphicsDeviceType.Vulkan;

            int score = 0;
            score += ramMb >= 12000 ? 4 : ramMb >= 8000 ? 3 : ramMb >= 6000 ? 2 : ramMb >= 4000 ? 1 : 0;
            score += cores >= 8 ? 1 : 0;
            score += gles3 ? 1 : 0;
            score += vulkan ? 1 : 0;

            QualityTier t = score >= 7 ? QualityTier.Ultra
                          : score >= 5 ? QualityTier.High
                          : score >= 3 ? QualityTier.Medium
                          : QualityTier.Low;

            // Battery/thermal safety: on handhelds never auto-pick Ultra; the user may opt in manually.
            if (Application.isMobilePlatform && t == QualityTier.Ultra) t = QualityTier.High;
            return t;
        }

        public static string Describe() =>
            $"{SystemInfo.deviceModel} | {SystemInfo.graphicsDeviceName} | RAM {SystemInfo.systemMemorySize}MB | " +
            $"cores {SystemInfo.processorCount} | API {SystemInfo.graphicsDeviceType} | {SystemInfo.operatingSystem}";
    }
}
