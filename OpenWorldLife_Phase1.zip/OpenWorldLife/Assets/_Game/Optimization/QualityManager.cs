using Game.Core;
using UnityEngine;
using UnityEngine.Rendering.Universal;

namespace Game.Optimization
{
    public struct QualityChanged { public QualityTier Tier; }

    public interface IQualityService
    {
        QualityProfile Current { get; }
        void SetTier(QualityTier tier, bool persist = true);
    }

    /// <summary>Applies a QualityProfile to Unity settings. First launch auto-recommends; user override is saved.</summary>
    public class QualityManager : IQualityService
    {
        const string PrefKey = "quality_tier";
        public QualityProfile Current { get; private set; }

        public void Initialize()
        {
            bool saved = PlayerPrefs.HasKey(PrefKey);
            QualityTier tier;
            if (saved) tier = (QualityTier)PlayerPrefs.GetInt(PrefKey);
            else { tier = DeviceProfiler.Recommend(); Debug.Log($"[Quality] Device: {DeviceProfiler.Describe()} -> {tier}"); }
            SetTier(tier, persist: saved);
        }

        public void SetTier(QualityTier tier, bool persist = true)
        {
            // TODO(Phase 18): load authored QualityProfile assets via Addressables; fall back to code defaults.
            Current = QualityProfile.CreateDefault(tier);
            Apply(Current);
            if (persist) { PlayerPrefs.SetInt(PrefKey, (int)tier); PlayerPrefs.Save(); }
            EventBus.Publish(new QualityChanged { Tier = tier });
        }

        static void Apply(QualityProfile p)
        {
            QualitySettings.vSyncCount = 0;
            Application.targetFrameRate = p.targetFps;
            QualitySettings.lodBias = p.lodBias;
            QualitySettings.globalTextureMipmapLimit = p.textureMipSkip;

            var urp = UniversalRenderPipeline.asset;
            if (urp != null)
            {
                urp.renderScale = p.renderScale;
                urp.msaaSampleCount = p.msaaLevel == 0 ? 1 : 1 << p.msaaLevel;
                urp.shadowDistance = p.shadowDistance;
            }
        }
    }
}
