using UnityEngine;

namespace Game.Optimization
{
    public enum QualityTier { Low = 0, Medium = 1, High = 2, Ultra = 3 }

    /// <summary>Tunable per-tier settings. Later phases read the budget fields (NPC/traffic caps, AI rate).</summary>
    [CreateAssetMenu(menuName = "Game/Quality Profile", fileName = "QualityProfile")]
    public class QualityProfile : ScriptableObject
    {
        public QualityTier tier = QualityTier.Medium;
        [Header("Rendering")]
        public int targetFps = 30;
        [Range(0.5f, 1f)] public float renderScale = 0.8f;
        [Range(0.5f, 1f)] public float minRenderScale = 0.6f;   // used by dynamic resolution (Phase 18)
        public bool dynamicResolution = true;
        public float shadowDistance = 40f;
        [Range(0, 3)] public int msaaLevel = 0;                 // 0..3 -> off,2x,4x,8x
        public float lodBias = 0.8f;
        public int textureMipSkip = 1;                          // 0 = full res
        public bool ssao, reflections, volumetricFog;
        [Header("Simulation budgets")]
        public int maxPedestrians = 20;
        public int maxTrafficVehicles = 10;
        public float aiTickHz = 5f;

        public static QualityProfile CreateDefault(QualityTier t)
        {
            var p = CreateInstance<QualityProfile>();
            p.name = "Default_" + t; p.tier = t;
            switch (t)
            {
                case QualityTier.Low:
                    p.targetFps = 30; p.renderScale = 0.65f; p.minRenderScale = 0.5f; p.shadowDistance = 20f;
                    p.msaaLevel = 0; p.lodBias = 0.6f; p.textureMipSkip = 2;
                    p.maxPedestrians = 10; p.maxTrafficVehicles = 6; p.aiTickHz = 3f; break;
                case QualityTier.Medium:
                    p.targetFps = 30; p.renderScale = 0.8f; p.shadowDistance = 40f;
                    p.msaaLevel = 0; p.lodBias = 0.8f; p.textureMipSkip = 1;
                    p.maxPedestrians = 20; p.maxTrafficVehicles = 12; p.aiTickHz = 5f; break;
                case QualityTier.High:
                    p.targetFps = 60; p.renderScale = 0.9f; p.minRenderScale = 0.7f; p.shadowDistance = 70f;
                    p.msaaLevel = 1; p.lodBias = 1.0f; p.textureMipSkip = 0; p.reflections = true;
                    p.maxPedestrians = 40; p.maxTrafficVehicles = 24; p.aiTickHz = 8f; break;
                default: // Ultra
                    p.targetFps = 60; p.renderScale = 1f; p.minRenderScale = 0.8f; p.shadowDistance = 100f;
                    p.msaaLevel = 2; p.lodBias = 1.3f; p.textureMipSkip = 0;
                    p.ssao = p.reflections = p.volumetricFog = true;
                    p.maxPedestrians = 70; p.maxTrafficVehicles = 40; p.aiTickHz = 10f; break;
            }
            return p;
        }
    }
}
